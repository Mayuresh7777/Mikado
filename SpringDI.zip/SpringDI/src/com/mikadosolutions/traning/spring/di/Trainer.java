package com.mikadosolutions.traning.spring.di;

import java.util.Set;

public interface Trainer {
	void train();
	Set<String> getSpecialties();
}
