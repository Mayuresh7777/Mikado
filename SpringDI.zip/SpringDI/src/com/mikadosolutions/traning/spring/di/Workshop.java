package com.mikadosolutions.traning.spring.di;

public interface Workshop {
	void conductWorkshop();

	void getCourseDetails();
}
