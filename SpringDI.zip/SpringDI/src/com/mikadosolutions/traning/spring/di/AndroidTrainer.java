package com.mikadosolutions.traning.spring.di;

import java.util.Set;

public class AndroidTrainer implements Trainer {

	String name;
	Set<String> specialties;

	public AndroidTrainer() {
	}

	public AndroidTrainer(String name, Set<String> specialties) {
		this.name = name;
		this.specialties = specialties;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSpecialties(Set<String> specialties) {
		this.specialties = specialties;
	}

	@Override
	public void train() {
		System.out.println(name + " is Training on Android");

	}

	@Override
	public Set<String> getSpecialties() {
		return specialties;
	}

	@Override
	public String toString() {
		return name + " is Android Trainer";
	}

}
