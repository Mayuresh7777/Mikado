package com.mikadosolutions.traning.spring.di;

import java.util.List;

public interface Course {
	int getCourseDuration();

	List<String> getCourseContents();

	double getCourseFees();
}
