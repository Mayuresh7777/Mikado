package com.mikadosolutions.traning.spring.di;

public interface TrainingCompany {
	void conductTraining();

	void getCourseDetails();
}
