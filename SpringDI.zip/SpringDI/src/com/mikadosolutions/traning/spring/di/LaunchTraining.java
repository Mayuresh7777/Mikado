package com.mikadosolutions.traning.spring.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;;

public class LaunchTraining {

	public static void main(String[] args) {
		ApplicationContext context = new FileSystemXmlApplicationContext(
				"C:\\Users\\Mikado Solutions\\Documents\\MayureshShinde\\SpringDI\\src\\com\\mikadosolutions\\traning\\spring\\di\\TrainingConfig.xml");
		Workshop trainingWorkshop = (Workshop) context.getBean("trainingWorkshop");
		trainingWorkshop.conductWorkshop();
		System.out.println("---------------------");
		System.out.println("Course Details");
		trainingWorkshop.getCourseDetails();
	}

}
