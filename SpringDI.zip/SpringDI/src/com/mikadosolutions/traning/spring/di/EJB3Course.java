package com.mikadosolutions.traning.spring.di;

import java.util.List;

public class EJB3Course implements Course {
	List<String> courseContents;
	int courseDuration;
	double courseFees;

	public EJB3Course() {
	}

	public EJB3Course(List<String> courseContents, int courseDuration, double courseFees) {
		this.courseContents = courseContents;
		this.courseDuration = courseDuration;
		this.courseFees = courseFees;
	}

	public List<String> getCourseContents() {
		return courseContents;
	}

	public void setCourseContents(List<String> courseContents) {
		this.courseContents = courseContents;
	}

	public int getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(int courseDuration) {
		this.courseDuration = courseDuration;
	}

	public double getCourseFees() {
		return courseFees;
	}

	public void setCourseFees(double courseFees) {
		this.courseFees = courseFees;
	}

	@Override
	public String toString() {
		return "EJB3 " + courseContents + " Duration is " + courseDuration + " Fees is " + courseFees;
	}
}
