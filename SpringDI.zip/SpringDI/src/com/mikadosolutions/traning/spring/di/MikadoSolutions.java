package com.mikadosolutions.traning.spring.di;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MikadoSolutions implements TrainingCompany {

	List<Trainer> trainers;
	static MikadoSolutions mikado;
	Set<Course> courses;
	Map<Course, Trainer> courseTrainers;

	private MikadoSolutions() {
	}

	public static MikadoSolutions getMikadoSolution() {
		if (mikado == null)
			mikado = new MikadoSolutions();
		return mikado;
	}

	public List<Trainer> getTrainers() {
		return trainers;
	}

	public void setTrainers(List<Trainer> trainers) {
		this.trainers = trainers;
	}

	public Set<Course> getCourses() {
		return courses;
	}

	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}

	public Map<Course, Trainer> getCourseTrainers() {
		return courseTrainers;
	}

	public void setCourseTrainers(Map<Course, Trainer> courseTrainers) {
		this.courseTrainers = courseTrainers;
		courses = courseTrainers.keySet();
		Collection<Trainer> values = courseTrainers.values();
		trainers = new ArrayList<Trainer>(values);
	}

	@Override
	public void conductTraining() {
		Iterator<Trainer> it = trainers.iterator();
		while (it.hasNext()) {
			Trainer trainer = it.next();
			System.out.println(trainer);
			trainer.train();
		}

	}

	public void getCourseDetails() {
		Iterator<Course> it = courses.iterator();
		while (it.hasNext()) {
			Course course = it.next();
			System.out.println(course);
		}
	}

	@Override
	public String toString() {
		return "Mikado Solutions is a Training Company";
	}

}
